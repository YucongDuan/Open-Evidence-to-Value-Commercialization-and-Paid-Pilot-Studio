# Authors

- Thought leadership and system architecture: **Yucong Duan (段玉聪)**
- Open-source implementation package: DIKWP-MESH8.1 E2V81 release team
