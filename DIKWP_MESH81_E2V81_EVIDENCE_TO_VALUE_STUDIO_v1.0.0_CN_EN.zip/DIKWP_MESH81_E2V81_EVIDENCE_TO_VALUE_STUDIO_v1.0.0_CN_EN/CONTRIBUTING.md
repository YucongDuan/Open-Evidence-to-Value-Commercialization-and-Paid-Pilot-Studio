# Contributing

1. Open an issue describing the buyer problem and expected evidence.
2. Keep pricing assumptions explicit and editable.
3. Never represent structural output as a legal, audit, certification, customs or market-access conclusion.
4. Add tests for new qualification, pricing and export logic.
5. Preserve D/I/K/W/P provenance and append-only audit records.
