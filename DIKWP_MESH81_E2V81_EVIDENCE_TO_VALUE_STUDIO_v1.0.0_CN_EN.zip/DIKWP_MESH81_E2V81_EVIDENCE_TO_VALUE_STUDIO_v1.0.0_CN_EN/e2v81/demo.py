from pathlib import Path
from .assessment import assess
from .qualification import qualify
from .pricing import quote
from .proposal import build_proposal
from .salesroom import make_salesroom
from .store import Store
from .util import write_json

def run(outdir):
    out=Path(outdir); out.mkdir(parents=True,exist_ok=True)
    answers={f'{a}{i:02d}':v for a,vals in {'MP':[4,4,3,2],'TV':[3,2,2,1],'EI':[2,1,2,1],'RG':[3,2,3,3],'SI':[3,2,2,3],'BO':[4,4,3,4]}.items() for i,v in enumerate(vals,1)}
    a=assess(answers); qf=qualify({'named_buyer':1,'specific_product_market':1,'data_owner':1,'budget_window':1,'professional_boundary':1,'market_pressure':3}); qt=quote('O03','high',data_sources=3,rule_packs=2,product_families=1,currency='CNY')
    props=build_proposal('Fictional Global Food Exporter','Demo Buyer <demo@example.invalid>',a,qf,qt,out/'proposal','cn')
    db=out/'demo.sqlite'; st=Store(db); st.add_org('ORG1','Fictional Global Food Exporter','CN'); st.add_lead('LEAD1','ORG1','Demo Buyer','demo@example.invalid','PROPOSAL','O03',qt['target']); st.stage('LEAD1','PAID_PILOT','Fictional demonstration only'); pipe=st.pipeline(); verify=st.verify(); st.close()
    room=make_salesroom(out/'E2V81_DEMO_SALES_ROOM.zip',list(props.values())+[db],{'fictional':True,'offer':'O03'})
    result={'assessment':a,'qualification':qf,'quote':qt,'proposal':props,'pipeline':pipe,'ledger':verify,'salesroom':room,'fictional':True}
    write_json(out/'demo_run.json',result); return result
