from __future__ import annotations
import hashlib, json, datetime as dt
from pathlib import Path

def canonical_json(value)->str:
    return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(",",":"))

def digest(value)->str:
    data=value if isinstance(value,(bytes,bytearray)) else canonical_json(value).encode("utf-8")
    return hashlib.sha256(data).hexdigest()

def utcnow()->str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()

def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def write_json(path,value):
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding="utf-8")
