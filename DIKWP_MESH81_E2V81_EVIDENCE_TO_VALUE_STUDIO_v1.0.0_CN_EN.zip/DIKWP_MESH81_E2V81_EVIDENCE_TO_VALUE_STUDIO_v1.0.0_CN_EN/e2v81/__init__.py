__version__ = "1.0.0"
SYSTEM_ID = "DIKWP-MESH8.1-E2V81"
