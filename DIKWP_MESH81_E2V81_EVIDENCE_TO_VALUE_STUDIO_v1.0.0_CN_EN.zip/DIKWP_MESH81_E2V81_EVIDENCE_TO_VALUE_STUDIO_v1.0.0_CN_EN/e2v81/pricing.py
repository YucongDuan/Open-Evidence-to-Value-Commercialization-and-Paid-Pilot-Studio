from .catalog import pricebook, offer_by_id

def quote(offer_id:str,complexity="base",data_sources=0,rule_packs=0,product_families=0,partner=False,currency="CNY"):
    pb=pricebook(); offer=offer_by_id(offer_id)
    if complexity not in pb["multipliers"]: raise ValueError("complexity must be low/base/high")
    base=pb["offer_base_cny"][offer_id]
    addons={
      "data_sources":int(data_sources)*pb["addons"]["data_source"],
      "rule_packs":int(rule_packs)*pb["addons"]["rule_pack"],
      "product_families":int(product_families)*pb["addons"]["product_family"],
    }
    subtotal=(base+sum(addons.values()))*pb["multipliers"][complexity]
    discount=subtotal*pb["partner_discount"] if partner else 0
    target=subtotal-discount
    low=target*0.9; high=target*1.2
    fx=pb["fx_cny_per_usd"]
    div=1 if currency.upper()=="CNY" else fx
    return {"offer":offer,"currency":currency.upper(),"complexity":complexity,"base":round(base/div,2),"addons":{k:round(v/div,2) for k,v in addons.items()},"partner_discount":round(discount/div,2),"low":round(low/div,2),"target":round(target/div,2),"high":round(high/div,2),"assumptions":pb,"boundary":"Transparent planning quote. No revenue guarantee; not a binding offer or market fact."}
