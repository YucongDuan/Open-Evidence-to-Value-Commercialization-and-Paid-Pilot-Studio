from __future__ import annotations
import sqlite3, json
from pathlib import Path
from .util import utcnow,digest,canonical_json
SCHEMA='''
CREATE TABLE IF NOT EXISTS organizations(id TEXT PRIMARY KEY,name TEXT NOT NULL,country TEXT,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS leads(id TEXT PRIMARY KEY,organization_id TEXT,name TEXT,email TEXT,stage TEXT,offer_id TEXT,value_cny REAL,owner TEXT,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS activities(id INTEGER PRIMARY KEY AUTOINCREMENT,lead_id TEXT,kind TEXT,note TEXT,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS audit_log(seq INTEGER PRIMARY KEY AUTOINCREMENT,event_type TEXT NOT NULL,payload_json TEXT NOT NULL,created_at TEXT NOT NULL,prev_hash TEXT NOT NULL,event_hash TEXT NOT NULL);
'''
class Store:
    def __init__(self,path):
        self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True); self.db=sqlite3.connect(self.path); self.db.row_factory=sqlite3.Row; self.db.executescript(SCHEMA); self.db.commit()
    def close(self): self.db.close()
    def audit(self,event_type,payload):
        row=self.db.execute("SELECT event_hash FROM audit_log ORDER BY seq DESC LIMIT 1").fetchone(); prev=row[0] if row else "0"*64; created=utcnow(); body={"event_type":event_type,"payload":payload,"created_at":created,"prev_hash":prev}; h=digest(body)
        self.db.execute("INSERT INTO audit_log(event_type,payload_json,created_at,prev_hash,event_hash) VALUES(?,?,?,?,?)",(event_type,canonical_json(payload),created,prev,h)); self.db.commit(); return h
    def add_org(self,org_id,name,country=""):
        self.db.execute("INSERT OR REPLACE INTO organizations VALUES(?,?,?,?)",(org_id,name,country,utcnow())); self.db.commit(); self.audit("ORG_UPSERT",{"id":org_id,"name":name})
    def add_lead(self,lead_id,org_id,name,email,stage="DISCOVERY",offer_id="O02",value_cny=0,owner="Yucong Duan"):
        now=utcnow(); self.db.execute("INSERT OR REPLACE INTO leads VALUES(?,?,?,?,?,?,?,?,?,?)",(lead_id,org_id,name,email,stage,offer_id,float(value_cny),owner,now,now)); self.db.commit(); self.audit("LEAD_UPSERT",{"id":lead_id,"stage":stage,"offer_id":offer_id,"value_cny":value_cny})
    def stage(self,lead_id,new_stage,note=""):
        now=utcnow(); self.db.execute("UPDATE leads SET stage=?,updated_at=? WHERE id=?",(new_stage,now,lead_id)); self.db.execute("INSERT INTO activities(lead_id,kind,note,created_at) VALUES(?,?,?,?)",(lead_id,"STAGE",note,now)); self.db.commit(); self.audit("STAGE_CHANGE",{"lead_id":lead_id,"stage":new_stage,"note":note})
    def pipeline(self): return [dict(r) for r in self.db.execute("SELECT * FROM leads ORDER BY updated_at DESC")]
    def verify(self):
        prev="0"*64
        for r in self.db.execute("SELECT * FROM audit_log ORDER BY seq"):
            body={"event_type":r["event_type"],"payload":json.loads(r["payload_json"]),"created_at":r["created_at"],"prev_hash":r["prev_hash"]}
            if r["prev_hash"]!=prev or digest(body)!=r["event_hash"]: return {"ok":False,"seq":r["seq"]}
            prev=r["event_hash"]
        return {"ok":True,"events":self.db.execute("SELECT COUNT(*) FROM audit_log").fetchone()[0],"head":prev}
