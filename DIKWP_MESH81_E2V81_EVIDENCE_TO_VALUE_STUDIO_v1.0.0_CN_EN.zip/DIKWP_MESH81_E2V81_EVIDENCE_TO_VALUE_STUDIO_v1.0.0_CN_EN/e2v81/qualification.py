GATES=["named_buyer","specific_product_market","data_owner","budget_window","professional_boundary"]

def qualify(context:dict)->dict:
    checks={g:bool(context.get(g)) for g in GATES}
    missing=[g for g,v in checks.items() if not v]
    if missing:
        next_offer="O01" if len(missing)>=3 else "O02"
        status="NURTURE_OR_DISCOVERY"
    else:
        pressure=context.get("market_pressure",0)
        next_offer="O03" if pressure>=2 else "O02"
        status="QUALIFIED_FOR_PAID_SCOPE"
    return {"status":status,"checks":checks,"missing":missing,"recommended_offer":next_offer,"boundary":"Qualification is a commercial workflow signal, not a legal or compliance conclusion."}
