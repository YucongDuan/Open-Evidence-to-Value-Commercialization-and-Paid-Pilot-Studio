from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,json
from .util import utcnow

def make_salesroom(output,files,metadata):
    out=Path(output); out.parent.mkdir(parents=True,exist_ok=True); manifest=[]
    with ZipFile(out,'w',ZIP_DEFLATED) as z:
        boundary="E2V81 sales room. No legal, audit, certification, customs, investment or market-access conclusion. Replace contact placeholders before use."
        z.writestr('BOUNDARY.txt',boundary)
        for f in files:
            p=Path(f); data=p.read_bytes(); arc='materials/'+p.name; z.writestr(arc,data); manifest.append({'path':arc,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
        payload={'created_at':utcnow(),'metadata':metadata,'files':manifest,'boundary':boundary}
        z.writestr('manifest.json',json.dumps(payload,ensure_ascii=False,indent=2))
    return {'path':str(out),'files':len(manifest),'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}

def verify_salesroom(path):
    with ZipFile(path) as z:
        m=json.loads(z.read('manifest.json'))
        for item in m['files']:
            if hashlib.sha256(z.read(item['path'])).hexdigest()!=item['sha256']: return {'ok':False,'path':item['path']}
        return {'ok':True,'files':len(m['files'])}
