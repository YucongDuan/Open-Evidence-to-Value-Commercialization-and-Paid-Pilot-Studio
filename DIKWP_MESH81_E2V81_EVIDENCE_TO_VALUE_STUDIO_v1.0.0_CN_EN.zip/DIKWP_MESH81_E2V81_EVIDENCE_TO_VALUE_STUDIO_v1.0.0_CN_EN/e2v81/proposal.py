from pathlib import Path
from .util import utcnow,write_json
from .minidocx import write_docx

def build_proposal(org,contact,assessment,qualification,quote,outdir,lang="cn"):
    d=Path(outdir); d.mkdir(parents=True,exist_ok=True); cn=lang.lower().startswith("cn")
    title=("E2V81 付费试点建议书" if cn else "E2V81 Paid-Pilot Proposal")+f" — {org}"
    lines=[f"Generated: {utcnow()}",f"Contact: {contact}","",("1. 业务目标" if cn else "1. Business objective"),
      ("将分散证据转化为可复核、可报价、可交付的产品级证据包。" if cn else "Convert fragmented evidence into a reviewable, scoped and deliverable product-level evidence package."),
      "",("2. 建议产品" if cn else "2. Recommended offer"),f"{quote['offer']['name_cn']} / {quote['offer']['name_en']}",
      f"Range: {quote['currency']} {quote['low']:,.0f} – {quote['high']:,.0f}; target {quote['target']:,.0f}",
      "",("3. 关键开放位置" if cn else "3. Open positions"),str({a:v['open_items'] for a,v in assessment['axis'].items()}),
      "",("4. 商业资格" if cn else "4. Commercial qualification"),str(qualification),
      "",("5. 边界" if cn else "5. Boundaries"),quote['boundary'],
      ("本建议书不构成法律、审计、认证、海关或市场准入结论。" if cn else "This proposal is not a legal, audit, certification, customs or market-access conclusion.")]
    stem='proposal_cn' if cn else 'proposal_en'; md=d/(stem+'.md'); html=d/(stem+'.html'); docx=d/(stem+'.docx'); js=d/(stem+'.json')
    md.write_text('# '+title+'\n\n'+'\n\n'.join(lines),encoding='utf-8')
    html.write_text('<!doctype html><meta charset="utf-8"><title>'+title+'</title><style>body{font-family:Arial,"Microsoft YaHei";max-width:900px;margin:40px auto;color:#10213A}h1{color:#0B3751}pre{white-space:pre-wrap}</style><h1>'+title+'</h1><pre>'+"\n\n".join(lines).replace('&','&amp;').replace('<','&lt;')+'</pre>',encoding='utf-8')
    write_docx(docx,title,lines); write_json(js,{"title":title,"organization":org,"contact":contact,"assessment":assessment,"qualification":qualification,"quote":quote})
    return {"md":str(md),"html":str(html),"docx":str(docx),"json":str(js)}
