from .catalog import questions
AXES=["MP","TV","EI","RG","SI","BO"]

def assess(answers:dict)->dict:
    qs=questions(); detail=[]; axis={a:{"answered":0,"possible":0,"observed":0,"open_items":[]} for a in AXES}
    for q in qs:
        raw=answers.get(q["id"])
        value=None if raw is None else max(0,min(4,int(raw)))
        a=axis[q["axis"]]; a["possible"]+=4
        if value is not None:
            a["answered"]+=1; a["observed"]+=value
            if value<3: a["open_items"].append(q["id"])
        else: a["open_items"].append(q["id"])
        detail.append({"id":q["id"],"axis":q["axis"],"value":value,"open":value is None or value<3})
    for a in AXES:
        s=axis[a]; s["evidence_ratio"]=round(s["observed"]/s["possible"],3) if s["possible"] else 0
        s["status"]="REVIEWABLE" if not s["open_items"] else "OPEN"
    return {"model":"six-axis-no-aggregate-score","axis":axis,"detail":detail,"boundary":"No aggregate quality/compliance score; gaps remain separately visible."}
