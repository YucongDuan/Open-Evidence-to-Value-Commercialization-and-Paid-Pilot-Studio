from .catalog import questions, offers, brand, pricebook
from importlib.resources import files
import json

def html():
    data=json.dumps({"questions":questions(),"offers":offers(),"brand":brand(),"pricebook":pricebook()},ensure_ascii=False)
    template=files("e2v81.resources").joinpath("dashboard.html").read_text(encoding="utf-8")
    return template.replace("__E2V_DATA__",data)
