import json
from pathlib import Path

def import_trace81(path):
    raw=json.loads(Path(path).read_text(encoding='utf-8'))
    open_items=[]
    def walk(v,p='root'):
        if isinstance(v,dict):
            for k,x in v.items():
                if str(x).upper() in {'MISSING','STALE','CONFLICT','OPEN','IDENTITY_REVIEW_REQUIRED','PROCESS_REVIEW'}: open_items.append({'path':p+'.'+k,'status':x})
                walk(x,p+'.'+k)
        elif isinstance(v,list):
            for i,x in enumerate(v): walk(x,f'{p}[{i}]')
    walk(raw)
    return {'source':'TRACE81','open_items':open_items,'count':len(open_items),'commercial_hint':'Use open evidence positions to scope O02 or O03; do not convert them into a compliance score.'}
