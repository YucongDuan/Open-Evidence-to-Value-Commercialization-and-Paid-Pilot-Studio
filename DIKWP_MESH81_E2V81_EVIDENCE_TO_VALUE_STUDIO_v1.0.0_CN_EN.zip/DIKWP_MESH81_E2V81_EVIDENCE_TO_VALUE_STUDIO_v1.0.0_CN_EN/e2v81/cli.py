from __future__ import annotations
import argparse,json,sys
from pathlib import Path
from .catalog import questions,offers,brand
from .assessment import assess
from .qualification import qualify
from .pricing import quote
from .demo import run
from .dashboard import html
from .salesroom import verify_salesroom
from .trace_bridge import import_trace81
from .store import Store

def dump(x): print(json.dumps(x,ensure_ascii=False,indent=2))
def main(argv=None):
    p=argparse.ArgumentParser(prog='e2v81'); s=p.add_subparsers(dest='cmd',required=True)
    s.add_parser('summary'); s.add_parser('questions'); s.add_parser('offers');
    d=s.add_parser('demo'); d.add_argument('--out',default='artifacts/demo')
    a=s.add_parser('assess'); a.add_argument('answers')
    q=s.add_parser('quote'); q.add_argument('offer'); q.add_argument('--complexity',default='base'); q.add_argument('--data-sources',type=int,default=0); q.add_argument('--rule-packs',type=int,default=0); q.add_argument('--product-families',type=int,default=0); q.add_argument('--partner',action='store_true'); q.add_argument('--currency',default='CNY')
    db=s.add_parser('dashboard'); db.add_argument('--out',default='E2V81_DASHBOARD.html')
    v=s.add_parser('verify-salesroom'); v.add_argument('path')
    t=s.add_parser('trace81-import'); t.add_argument('path')
    pl=s.add_parser('pipeline'); pl.add_argument('database')
    sv=s.add_parser('serve'); sv.add_argument('--directory',default='.'); sv.add_argument('--host',default='127.0.0.1'); sv.add_argument('--port',type=int,default=8000)
    s.add_parser('selftest')
    x=p.parse_args(argv)
    if x.cmd=='summary': dump({'system':'DIKWP-MESH8.1 E2V81','version':'1.0.0','questions':len(questions()),'offers':len(offers()),'tagline':brand()['tagline_en'],'boundary':'No revenue, legal, audit, certification or market-access guarantee.'})
    elif x.cmd=='questions': dump(questions())
    elif x.cmd=='offers': dump(offers())
    elif x.cmd=='demo': dump(run(x.out))
    elif x.cmd=='assess': dump(assess(json.loads(Path(x.answers).read_text(encoding='utf-8'))))
    elif x.cmd=='quote': dump(quote(x.offer,x.complexity,x.data_sources,x.rule_packs,x.product_families,x.partner,x.currency))
    elif x.cmd=='dashboard': Path(x.out).write_text(html(),encoding='utf-8'); print(x.out)
    elif x.cmd=='verify-salesroom': dump(verify_salesroom(x.path))
    elif x.cmd=='trace81-import': dump(import_trace81(x.path))
    elif x.cmd=='pipeline':
        st=Store(x.database); dump({'pipeline':st.pipeline(),'ledger':st.verify()}); st.close()
    elif x.cmd=='serve':
        from .server import serve; serve(x.directory,x.host,x.port)
    elif x.cmd=='selftest':
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            result=run(d); ok=result['ledger']['ok'] and Path(result['salesroom']['path']).exists() and len(questions())==24 and len(offers())==6
            dump({'ok':ok,'questions':24,'offers':6,'quote_target':result['quote']['target'],'ledger_events':result['ledger']['events']}); return 0 if ok else 1
    return 0
