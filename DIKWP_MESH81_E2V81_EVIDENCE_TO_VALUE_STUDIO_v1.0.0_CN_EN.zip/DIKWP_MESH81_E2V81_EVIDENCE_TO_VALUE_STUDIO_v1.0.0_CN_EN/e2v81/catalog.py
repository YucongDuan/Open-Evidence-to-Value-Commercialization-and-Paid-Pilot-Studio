from importlib.resources import files
import json

def _load(name):
    return json.loads(files("e2v81.resources").joinpath(name).read_text(encoding="utf-8"))
def questions(): return _load("questions.json")
def offers(): return _load("offers.json")
def pricebook(): return _load("pricebook.json")
def brand(): return _load("brand.json")
def offer_by_id(offer_id):
    for item in offers():
        if item["id"]==offer_id: return item
    raise KeyError(offer_id)
