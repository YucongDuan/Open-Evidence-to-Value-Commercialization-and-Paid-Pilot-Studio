from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from functools import partial

def serve(directory,host='127.0.0.1',port=8000):
    print(f'Serving {directory} at http://{host}:{port}')
    ThreadingHTTPServer((host,port),partial(SimpleHTTPRequestHandler,directory=directory)).serve_forever()
