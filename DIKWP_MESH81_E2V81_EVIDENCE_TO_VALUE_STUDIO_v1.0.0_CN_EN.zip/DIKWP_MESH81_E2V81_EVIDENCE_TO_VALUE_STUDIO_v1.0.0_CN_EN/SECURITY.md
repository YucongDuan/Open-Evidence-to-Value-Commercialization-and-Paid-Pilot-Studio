# Security

Report vulnerabilities privately to `REPLACE_WITH_SECURITY_CONTACT`. Do not include personal data, customer evidence, credentials, legal files, or confidential supply-chain records in public issues. The demonstration database and cases are fictional.
