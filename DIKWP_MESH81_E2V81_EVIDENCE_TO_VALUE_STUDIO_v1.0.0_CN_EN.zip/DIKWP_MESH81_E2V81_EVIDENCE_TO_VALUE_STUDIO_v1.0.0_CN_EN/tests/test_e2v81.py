import json,tempfile,unittest
from pathlib import Path
from e2v81.catalog import questions,offers,pricebook,brand,offer_by_id
from e2v81.assessment import assess
from e2v81.qualification import qualify
from e2v81.pricing import quote
from e2v81.store import Store
from e2v81.minidocx import write_docx
from e2v81.proposal import build_proposal
from e2v81.salesroom import make_salesroom,verify_salesroom
from e2v81.trace_bridge import import_trace81
from e2v81.dashboard import html
from e2v81.demo import run
class T(unittest.TestCase):
 def test_01_questions(self): self.assertEqual(len(questions()),24)
 def test_02_axes(self): self.assertEqual(sorted(set(q['axis'] for q in questions())),['BO','EI','MP','RG','SI','TV'])
 def test_03_offers(self): self.assertEqual(len(offers()),6)
 def test_04_offer(self): self.assertEqual(offer_by_id('O03')['base_cny'],680000)
 def test_05_brand(self): self.assertIn('REPLACE_',brand()['contact_email'])
 def test_06_assess(self): self.assertEqual(assess({})['axis']['MP']['status'],'OPEN')
 def test_07_assess_full(self): self.assertEqual(assess({q['id']:4 for q in questions()})['axis']['EI']['status'],'REVIEWABLE')
 def test_08_no_aggregate(self): self.assertNotIn('score',assess({}))
 def test_09_qualify(self): self.assertEqual(qualify({})['status'],'NURTURE_OR_DISCOVERY')
 def test_10_qualify_paid(self): self.assertEqual(qualify({g:1 for g in ['named_buyer','specific_product_market','data_owner','budget_window','professional_boundary']}|{'market_pressure':3})['recommended_offer'],'O03')
 def test_11_quote(self): self.assertEqual(quote('O03')['target'],680000)
 def test_12_quote_addons(self): self.assertGreater(quote('O03',data_sources=1)['target'],680000)
 def test_13_quote_partner(self): self.assertLess(quote('O03',partner=True)['target'],680000)
 def test_14_quote_usd(self): self.assertAlmostEqual(quote('O03',currency='USD')['target'],680000/7.2,places=2)
 def test_15_store(self):
  with tempfile.TemporaryDirectory() as d:
   s=Store(Path(d)/'a.sqlite'); s.add_org('o','x'); s.add_lead('l','o','n','e'); self.assertTrue(s.verify()['ok']); s.close()
 def test_16_stage(self):
  with tempfile.TemporaryDirectory() as d:
   s=Store(Path(d)/'a.sqlite'); s.add_org('o','x'); s.add_lead('l','o','n','e'); s.stage('l','PAID'); self.assertEqual(s.pipeline()[0]['stage'],'PAID'); s.close()
 def test_17_docx(self):
  with tempfile.TemporaryDirectory() as d:
   p=write_docx(Path(d)/'x.docx','t',['p']); self.assertTrue(Path(p).exists())
 def test_18_proposal(self):
  with tempfile.TemporaryDirectory() as d:
   a=assess({}); q=qualify({}); qt=quote('O02'); x=build_proposal('Org','Name',a,q,qt,d); self.assertTrue(Path(x['docx']).exists())
 def test_19_salesroom(self):
  with tempfile.TemporaryDirectory() as d:
   f=Path(d)/'a.txt'; f.write_text('x'); z=make_salesroom(Path(d)/'x.zip',[f],{}); self.assertTrue(verify_salesroom(z['path'])['ok'])
 def test_20_trace(self):
  with tempfile.TemporaryDirectory() as d:
   f=Path(d)/'x.json'; f.write_text(json.dumps({'status':'MISSING'})); self.assertEqual(import_trace81(f)['count'],1)
 def test_21_dashboard(self): self.assertIn('24问',html())
 def test_22_dashboard_offers(self): self.assertIn('O03',html())
 def test_23_demo(self):
  with tempfile.TemporaryDirectory() as d: self.assertTrue(run(d)['ledger']['ok'])
 def test_24_boundary(self): self.assertIn('No revenue',quote('O02')['boundary'])
if __name__=='__main__': unittest.main()
