$ErrorActionPreference = "Stop"
python -m e2v81 demo --out artifacts/demo
python -m e2v81 dashboard --out OPEN_DASHBOARD.html
