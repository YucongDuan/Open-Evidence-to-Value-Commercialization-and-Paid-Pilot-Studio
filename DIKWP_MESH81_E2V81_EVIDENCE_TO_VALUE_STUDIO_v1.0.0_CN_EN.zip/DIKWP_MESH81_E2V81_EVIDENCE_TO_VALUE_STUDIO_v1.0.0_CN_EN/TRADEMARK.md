# Trademark Notice

Apache-2.0 grants rights to code, not to trademarks. Before public launch, complete a trademark search for **E2V81**, **证据价值转化工场**, and related logos. Third parties may not imply official certification, endorsement, or partnership without written permission.
