# Public Launch Checklist

- [ ] 替换公开邮箱、微信/渠道和网站
- [ ] 确定签约与开票主体
- [ ] 完成 E2V81 名称与标识的商标检索
- [ ] 律师审阅免责声明、SOW 和伙伴协议
- [ ] 删除演示客户可能引发误解的内容
- [ ] 在 GitHub 启用 Issues、Discussions、Security 与 Release
- [ ] 上传中英文报告、一页纸、PPT、XLSX 和营销包
- [ ] 建立 30 分钟范围确认预约入口
- [ ] 预设付费诊断的交付日历与资源
