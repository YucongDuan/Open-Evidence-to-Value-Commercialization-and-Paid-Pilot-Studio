# Architecture

```text
Public research & repositories
        ↓
15-minute scope call
        ↓
24-question six-axis diagnostic
        ↓
qualification gates + transparent pricebook
        ↓
proposal + sales room + append-only audit trail
        ↓
paid pilot
        ↓
rollout / annual subscription / partner program
```

D 保存来源和承诺；I 保留缺失、冲突和所有权差异；K 是当前交易整体；W 保存买方、市场、责任和边界；P 保存发现、报价、提案、成交、交付、续费和回返。
