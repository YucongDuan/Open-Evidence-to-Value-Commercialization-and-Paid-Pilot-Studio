# Public Source Ledger

1. U.S. CBP UFLPA: https://www.cbp.gov/trade/forced-labor/UFLPA
2. CBP UFLPA importer guidance: https://www.cbp.gov/document/guidance/uflpa-operational-guidance-importers
3. European Commission Digital Product Passport: https://single-market-economy.ec.europa.eu/single-market/goods/ecodesign-sustainable-products-regulation/digital-product-passport_en
4. GS1 EPCIS / CBV 2.0.1: https://ref.gs1.org/standards/epcis/
5. W3C Verifiable Credentials Data Model 2.0: https://www.w3.org/TR/vc-data-model-2.0/
6. Yucong Duan GitHub repositories: https://github.com/YucongDuan?tab=repositories

All time-sensitive legal and regulatory facts must be rechecked before publication or customer use.
